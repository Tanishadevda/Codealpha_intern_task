
    const image = document.getElementsByClassName("images");
    // elements lightbox
    const lightBoxContainer = document.createElement("div");
    // element for area
    const lightBoxContent = document.createElement("div");
    // for img
    const lightBoxImg = document.createElement("img");
    // for prev button
    const lightBoxPrev = document.createElement("div");
    // next button
    const lightBoxNext = document.createElement("div");

    // creating classlist

    lightBoxContainer.classList.add('lightbox');
    lightBoxContent.classList.add('lightbox-content');
    lightBoxPrev.classList.add("fa", "fa-angle-left", "lightbox-prev");
    lightBoxNext.classList.add("fa", "fa-angle-right", "lightbox-next");

    lightBoxContainer.appendChild(lightBoxContent);
    lightBoxContent.appendChild(lightBoxImg);
    lightBoxContent.appendChild(lightBoxPrev);
    lightBoxContent.appendChild(lightBoxNext);
    document.body.appendChild(lightBoxContainer);

    let index = 1;

    //function 
    function showLigthBox(n) {
        if (n > image.length) {
            index = 1;
        }
        else if (n < 1) {
            index = image.length;
        }

        let imageLocation = image[index - 1].children[0].getAttribute("src");
        lightBoxImg.setAttribute("src", imageLocation);
    }

    function currentImage() {
        lightBoxContainer.style.display = "block";

        let imgIndex = parseInt(this.getAttribute("data-index"));
        showLigthBox(index = imgIndex);

    }


    for (let i = 0; i < image.length; i++) {
        image[i].addEventListener("click", currentImage);
    }

    function sliderImage(n) {
        showLigthBox(index += n);
    }

    function prevImage() {
        sliderImage(-1);

    }

    function nextImage() {
        sliderImage(1);
    }

    lightBoxPrev.addEventListener("click", prevImage);
    lightBoxNext.addEventListener("click", nextImage);

    // lightbox close

    function closeLightBox() {
        if (this === event.target) {
            lightBoxContainer.style.display = "none";
        }
    }

    lightBoxContainer.addEventListener("click", closeLightBox);

// second slide //

let nextbtn = document.querySelector('.next');
let prevbtn = document.querySelector('.prev');

let slider = document.querySelector('.slider');
let sliderlist = slider.querySelector('.slider .list');
let thumbnail = document.querySelector('.thumbnail');
let thumbitems = thumbnail.querySelectorAll('.items');


thumbnail.appendChild(thumbitems[0]);


nextbtn.onclick = function(){
    moveSlider('next');
}


prevbtn.onclick = function(){
    moveSlider('prev');
}

function moveSlider(direction) {
    let slideritems = sliderlist.querySelectorAll('.items');
    let thumbitems = document.querySelectorAll('.thumbnail .items');
    if(direction === 'next'){
        sliderlist.appendChild(slideritems[0]);
        thumbnail.appendChild(thumbitems[0]);
        slider.classList.add('next');
    }

    else{
        sliderlist.prepend(slideritems[slideritems.length - 1]);
        thumbnail.prepend(thumbitems[thumbitems.length - 1]);
        slider.classList.add('prev');
    }
}

slider.addEventListener('animationed' , function() {
    if(direction === 'next'){
        slider.classList.remove('next');
    }
    else{
        slider.classList.remove('prev');
    }
} )
 {once: true}




